if (parent.frames.length != 0) {
parent.location.href = location.href
}