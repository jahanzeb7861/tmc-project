function minmaj() {
txt = document.transcription.text2.value.toUpperCase();
document.transcription.text2.value = txt;
} 
